Made by: Patrick Rocha

Slime Fighters is a 2-player game. The objecive is to hit your
opponent 3 times. The first one to accomplish this wins.

-------------------------------------------------------------------------

CONTROLS
Player 1:
Move: WASD
Jump: Space
Attack: I
Airdash: U

Player 2:
Move: Arrow keys
Jump: Numpad0
Attack: Numpad9
Airdash: Numpad8